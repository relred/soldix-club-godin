<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    // title of the card
    'title' => null,
    // should the card be displayed with a shadow
    'has_shadow' => true,
    // for backward compatibility with Laravel 8
    'hasShadow' => true,
    // reduce padding within the card
    'reduce_padding' => false,
    // for backward compatibility with Laravel 8
    'reducePadding' => false,
    // content to display as card header
    'header' => null,
    // content to display as card footer
    'footer' => null,
    // additional css
    'class' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    // title of the card
    'title' => null,
    // should the card be displayed with a shadow
    'has_shadow' => true,
    // for backward compatibility with Laravel 8
    'hasShadow' => true,
    // reduce padding within the card
    'reduce_padding' => false,
    // for backward compatibility with Laravel 8
    'reducePadding' => false,
    // content to display as card header
    'header' => null,
    // content to display as card footer
    'footer' => null,
    // additional css
    'class' => null,
]); ?>
<?php foreach (array_filter(([
    // title of the card
    'title' => null,
    // should the card be displayed with a shadow
    'has_shadow' => true,
    // for backward compatibility with Laravel 8
    'hasShadow' => true,
    // reduce padding within the card
    'reduce_padding' => false,
    // for backward compatibility with Laravel 8
    'reducePadding' => false,
    // content to display as card header
    'header' => null,
    // content to display as card footer
    'footer' => null,
    // additional css
    'class' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    $has_shadow = filter_var($has_shadow, FILTER_VALIDATE_BOOLEAN);
    $hasShadow = filter_var($hasShadow, FILTER_VALIDATE_BOOLEAN);
    $reduce_padding = filter_var($reduce_padding, FILTER_VALIDATE_BOOLEAN);
    $reducePadding = filter_var($reducePadding, FILTER_VALIDATE_BOOLEAN);
    if ( !$hasShadow ) $has_shadow = $hasShadow;
    if ( $reducePadding ) $reduce_padding = $reducePadding;
?>
<div class="bw-card bg-white <?php if($header === null && ! $reduce_padding): ?> p-8 <?php elseif($reduce_padding): ?> p-4 <?php else: ?> <?php endif; ?> rounded-lg <?php if($has_shadow): ?> shadow-2xl shadow-gray-200/40 <?php endif; ?> <?php echo e($class); ?>">
    <?php if($header): ?>
        <div class="border-b border-gray-100/30">
            <?php echo e($header); ?>

        </div>
    <?php endif; ?>
    <?php if($title && ! $header): ?>
        <div class="uppercase tracking-wide text-xs text-gray-500/90 mb-2"><?php echo e($title); ?></div>
    <?php endif; ?>
    <div <?php if($title && ! $header): ?> class="mt-6" <?php endif; ?>>
        <?php echo e($slot); ?>

    </div>
    <?php if($footer): ?>
        <div class="border-t border-gray-100/30">
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\vendor\mkocansey\bladewind\src/../resources/views/components/card.blade.php ENDPATH**/ ?>