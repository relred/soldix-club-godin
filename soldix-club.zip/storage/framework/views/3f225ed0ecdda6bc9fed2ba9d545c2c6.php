<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'image' => asset('vendor/bladewind/images/empty-state.svg'),
    'heading' => '',
    'button_label' => '', // button will not be displayed if no text is passed
    'buttonLabel' => '',
    'message' => '',   // message to display
    'show_image' => true, // true or false. set to false if you want to fully control the content
    'showImage' => true,
    'onclick' => '',
    'class' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'image' => asset('vendor/bladewind/images/empty-state.svg'),
    'heading' => '',
    'button_label' => '', // button will not be displayed if no text is passed
    'buttonLabel' => '',
    'message' => '',   // message to display
    'show_image' => true, // true or false. set to false if you want to fully control the content
    'showImage' => true,
    'onclick' => '',
    'class' => '',
]); ?>
<?php foreach (array_filter(([
    'image' => asset('vendor/bladewind/images/empty-state.svg'),
    'heading' => '',
    'button_label' => '', // button will not be displayed if no text is passed
    'buttonLabel' => '',
    'message' => '',   // message to display
    'show_image' => true, // true or false. set to false if you want to fully control the content
    'showImage' => true,
    'onclick' => '',
    'class' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    $show_image = filter_var($show_image, FILTER_VALIDATE_BOOLEAN);
    $showImage = filter_var($showImage, FILTER_VALIDATE_BOOLEAN);
    if ($buttonLabel !== $button_label) $button_label = $buttonLabel;
    if (! $showImage) $show_image = $showImage;
?>
<div class="text-center px-4 pb-10 bw-empty-state <?php echo e($class); ?>">
    <?php if($show_image == 'true'): ?><img src="<?php echo e($image); ?>" class="h-52 mx-auto mb-6" /><?php endif; ?>
    <?php if($heading != ''): ?><div class="text-slate-700 text-2xl pt-4 pb-3 px-4 font-light"><?php echo $heading; ?></div><?php endif; ?>
    <?php if($message != ''): ?><div class="text-slate-600/70 px-6"><?php echo $message; ?></div><?php endif; ?>
    <div class="pt-2"><?php echo $slot; ?></div>
    <?php if($button_label != ''): ?>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button','data' => ['onclick' => ''.$onclick.'','class' => 'block mx-auto my-4','size' => 'small']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => ''.$onclick.'','class' => 'block mx-auto my-4','size' => 'small']); ?><?php echo e($button_label); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\vendor\mkocansey\bladewind\src/../resources/views/components/empty-state.blade.php ENDPATH**/ ?>