<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    // your table headers in <th></th> tags
    'header' => '',
    // setting to true will result in a striped table
    'striped' => false,
    // should the table with displayed with a dropshadow effect
    'has_shadow' => false,
    'hasShadow' => false,
    // should the table have row dividers
    'divided' => true,
    // if table has row dividers, how wide should they be
    // available value are regular, thin
    'divider' => 'regular',
    // should rows light up on hover
    'hover_effect' => true,
    'hoverEffect' => true,
    // should the rows be tighter together
    'compact' => false,
    // provide a table name you can access via css
    'name' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    // your table headers in <th></th> tags
    'header' => '',
    // setting to true will result in a striped table
    'striped' => false,
    // should the table with displayed with a dropshadow effect
    'has_shadow' => false,
    'hasShadow' => false,
    // should the table have row dividers
    'divided' => true,
    // if table has row dividers, how wide should they be
    // available value are regular, thin
    'divider' => 'regular',
    // should rows light up on hover
    'hover_effect' => true,
    'hoverEffect' => true,
    // should the rows be tighter together
    'compact' => false,
    // provide a table name you can access via css
    'name' => '',
]); ?>
<?php foreach (array_filter(([
    // your table headers in <th></th> tags
    'header' => '',
    // setting to true will result in a striped table
    'striped' => false,
    // should the table with displayed with a dropshadow effect
    'has_shadow' => false,
    'hasShadow' => false,
    // should the table have row dividers
    'divided' => true,
    // if table has row dividers, how wide should they be
    // available value are regular, thin
    'divider' => 'regular',
    // should rows light up on hover
    'hover_effect' => true,
    'hoverEffect' => true,
    // should the rows be tighter together
    'compact' => false,
    // provide a table name you can access via css
    'name' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php 
    // reset variables for Laravel 8 support
    $has_shadow = filter_var($has_shadow, FILTER_VALIDATE_BOOLEAN);
    $hasShadow = filter_var($hasShadow, FILTER_VALIDATE_BOOLEAN);
    $hover_effect = filter_var($hover_effect, FILTER_VALIDATE_BOOLEAN);
    $hoverEffect = filter_var($hoverEffect, FILTER_VALIDATE_BOOLEAN);
    $striped = filter_var($striped, FILTER_VALIDATE_BOOLEAN);
    $compact = filter_var($compact, FILTER_VALIDATE_BOOLEAN);
    $divided = filter_var($divided, FILTER_VALIDATE_BOOLEAN);
    if ($hasShadow) $has_shadow = $hasShadow;
    if (!$hoverEffect) $hover_effect = $hoverEffect;
?>
<div class="z-20"> 
    <div class="w-full">
        <table class="bw-table w-full <?php echo e($name); ?> <?php if($has_shadow): ?> shadow-2xl shadow-gray-200 <?php endif; ?>  <?php if($divided): ?> divided <?php if($divider=='thin'): ?> thin <?php endif; ?> <?php endif; ?>  <?php if($striped): ?> striped <?php endif; ?> <?php if($hover_effect): ?> with-hover-effect <?php endif; ?> <?php if($compact): ?> compact <?php endif; ?>">
            <thead>
                <tr class="bg-gray-200"><?php echo e($header); ?></tr>
            </thead>
            <tbody><?php echo e($slot); ?></tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\vendor\mkocansey\bladewind\src/../resources/views/components/table.blade.php ENDPATH**/ ?>