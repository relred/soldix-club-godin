<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="grid place-content-center my-3">
        <img src="https://res.cloudinary.com/de6hiq5n4/image/upload/v1678864326/comercia_logo_negro_naranja-01_cpvddz.png" alt="COMERCIA" class="max-w-xs">
    </div>
    <h2 class="text-4xl text-center">
        Descubra cuánto podría ganar con una licencia Comercia
    </h2>
    <p class="text-sm text-gray-500 text-center mt-2">La proyección de las ganancias puede tener ligeras variaciones dependiendo de la ubicación de los clientes y otros factores.</p>
    <div class="mt-3 mb-4">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('revenue-projection', [])->html();
} elseif ($_instance->childHasBeenRendered('ZIFNk19')) {
    $componentId = $_instance->getRenderedChildComponentId('ZIFNk19');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZIFNk19');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZIFNk19');
} else {
    $response = \Livewire\Livewire::mount('revenue-projection', []);
    $html = $response->html();
    $_instance->logRenderedChild('ZIFNk19', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\resources\views/test.blade.php ENDPATH**/ ?>