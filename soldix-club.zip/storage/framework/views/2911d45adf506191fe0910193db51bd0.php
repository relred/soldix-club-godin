<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'image' => null,
    'alt' => 'image',
    'size' => 'regular',
    'class' => 'mr-2 mt-2',
    'stacked' => false,
    'sizing' => [
        'tiny' => 6,
        'small' => 8,
        'medium' => 10,
        'regular' => 12,
        'big' => 16,
        'huge' => 20,
        'omg' => 28
    ]
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'image' => null,
    'alt' => 'image',
    'size' => 'regular',
    'class' => 'mr-2 mt-2',
    'stacked' => false,
    'sizing' => [
        'tiny' => 6,
        'small' => 8,
        'medium' => 10,
        'regular' => 12,
        'big' => 16,
        'huge' => 20,
        'omg' => 28
    ]
]); ?>
<?php foreach (array_filter(([
    'image' => null,
    'alt' => 'image',
    'size' => 'regular',
    'class' => 'mr-2 mt-2',
    'stacked' => false,
    'sizing' => [
        'tiny' => 6,
        'small' => 8,
        'medium' => 10,
        'regular' => 12,
        'big' => 16,
        'huge' => 20,
        'omg' => 28
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $avatar = $image ?: asset('vendor/bladewind/images/avatar.png');
    $stacked = filter_var($stacked, FILTER_VALIDATE_BOOLEAN);;
?>

<span class="w-6 w-8 w-10 w-12 w-16 w-20 w-28 h-6 h-8 h-10 h-12 h-16 h-20 h-28 hidden"></span>
<div class="w-<?php echo e($sizing[$size]); ?> h-<?php echo e($sizing[$size]); ?> inline-block rounded-full ring-2 ring-gray-200 dark:ring-slate-600 ring-offset-2 overflow-hidden <?php echo e($class); ?> <?php if($stacked): ?> -ml-5 <?php endif; ?>">
    <img src="<?php echo e($avatar); ?>" alt="<?php echo e($alt); ?>" class="object-cover object-top" />
</div>
<?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\vendor\mkocansey\bladewind\src/../resources/views/components/avatar.blade.php ENDPATH**/ ?>