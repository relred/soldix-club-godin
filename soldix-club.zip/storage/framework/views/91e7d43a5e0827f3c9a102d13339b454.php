<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'size' => 'small',
    'class' => '',
    'sizing' => [
        'small' => 6,
        'medium' => 10,
        'big' => 14,
        'xl' => 24,
        'omg' => 36
    ],
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'size' => 'small',
    'class' => '',
    'sizing' => [
        'small' => 6,
        'medium' => 10,
        'big' => 14,
        'xl' => 24,
        'omg' => 36
    ],
]); ?>
<?php foreach (array_filter(([
    'size' => 'small',
    'class' => '',
    'sizing' => [
        'small' => 6,
        'medium' => 10,
        'big' => 14,
        'xl' => 24,
        'omg' => 36
    ],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<svg class="animate-spin inline-block bw-spinner h-<?php echo e($sizing[$size]); ?> w-<?php echo e($sizing[$size]); ?> <?php echo e($class); ?>" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
<span class="hidden w-6 w-10 w-14 w-24 w-36 h-6 h-10 h-14 h-24 h-36"></span><?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\vendor\mkocansey\bladewind\src/../resources/views/components/spinner.blade.php ENDPATH**/ ?>