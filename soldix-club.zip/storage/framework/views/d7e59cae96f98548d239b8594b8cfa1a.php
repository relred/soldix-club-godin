<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Boletera')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.centered-content','data' => ['class' => 'py-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::centered-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'py-12']); ?>

        <div class="relative w-full group max-w-md min-w-0 mx-auto mt-12 mb-6 break-words bg-white border shadow-2xl dark:bg-gray-800 dark:border-gray-700 md:max-w-sm rounded-2xl">
            <div class="pb-6">
                <div class="flex flex-wrap justify-center">
                    <div class="flex justify-center w-full">
                        <div class="relative">
                            <?php if($wallet->image): ?>
                                <img src="<?php echo e($wallet->image); ?>" class="dark:shadow-xl border-white dark:border-gray-800 rounded-3xl align-middle border-8 absolute -m-16 -ml-18 lg:-ml-16 max-w-[150px]" />
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="mt-24 text-center">
                    <h3 class="mb-1 text-2xl font-bold leading-normal text-gray-700 dark:text-gray-300">
                        <?php if($wallet->name): ?>
                            <?php echo e($wallet->name); ?>

                        <?php else: ?>
                            <?php echo e($wallet->brand->name); ?>

                        <?php endif; ?>
                    </h3>
                    <h3 class="mb-4 text-xl font-bold leading-normal text-red-600/90 dark:text-gray-300">
                        <?php echo e($wallet->getBrand()); ?>

                    </h3>
                </div>


                <div class="relative h-6 overflow-hidden translate-y-6 rounded-b-xl">
                    <div class="absolute flex -space-x-12 rounded-b-2xl">
                        <div class="w-36 h-8 transition-colors duration-200 delay-75 transform skew-x-[35deg] bg-red-400/90 group-hover:bg-red-600/90 z-10"></div>
                        <div class="w-28 h-8 transition-colors duration-200 delay-100 transform skew-x-[35deg] bg-red-300/90 group-hover:bg-red-500/90 z-20"></div>
                        <div class="w-28 h-8 transition-colors duration-200 delay-150 transform skew-x-[35deg] bg-red-200/90 group-hover:bg-red-400/90 z-30"></div>
                        <div class="w-28 h-8 transition-colors duration-200 delay-200 transform skew-x-[35deg] bg-red-100/90 group-hover:bg-red-300/90 z-40"></div>
                        <div class="w-28 h-8 transition-colors duration-200 delay-300 transform skew-x-[35deg] bg-red-50/90 group-hover:bg-red-200/90 z-50"></div>
                    </div>
                </div>
            </div>
        </div>


        <div class="grid sm:grid-cols-2 pb-16">
            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063 = $component; } ?>
<?php $component = App\View\Components\Coupon::resolve(['id' => ''.e($coupon->id).'','type' => ''.e($coupon->type).'','tag' => ''.e($coupon->tag).'','valid' => 'Consulte validez en interior'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('coupon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Coupon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('image', null, []); ?> 
                        <?php echo e($coupon->image); ?>

                     <?php $__env->endSlot(); ?>
                    <?php echo e($coupon->name); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063)): ?>
<?php $component = $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063; ?>
<?php unset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\resources\views/user/wallet/view.blade.php ENDPATH**/ ?>