<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'name' => 'checkbox',
    'value' => null,
    'label' => null,
    'checked' => false,
    'disabled' => false,
    'type' => 'checkbox',
    'class' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'name' => 'checkbox',
    'value' => null,
    'label' => null,
    'checked' => false,
    'disabled' => false,
    'type' => 'checkbox',
    'class' => null,
]); ?>
<?php foreach (array_filter(([
    'name' => 'checkbox',
    'value' => null,
    'label' => null,
    'checked' => false,
    'disabled' => false,
    'type' => 'checkbox',
    'class' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    $name = preg_replace('/[\s-]/', '_', $name);
    $checked = filter_var($checked, FILTER_VALIDATE_BOOLEAN);
    $disabled = filter_var($disabled, FILTER_VALIDATE_BOOLEAN);
?>

<label class="inline-flex items-center cursor-pointer text-sm <?php if($disabled): ?> opacity-60 <?php endif; ?> <?php echo e($class); ?>">
    <input
        type="<?php echo e($type); ?>"
        name="<?php echo e($name); ?>"
        class="text-blue-500 w-5 h-5 mr-2 disabled:opacity-60 focus:ring-blue-400 focus:ring-opacity-25 border border-gray-300 bw-checkbox rounded"
        <?php if($disabled): ?> disabled <?php endif; ?>
        <?php if($checked): ?> checked <?php endif; ?>
        value="<?php echo e($value); ?>"
    />
    <?php echo $label; ?>

</label>
<?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\vendor\mkocansey\bladewind\src/../resources/views/components/checkbox.blade.php ENDPATH**/ ?>