<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Detalles de cupón')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.centered-content','data' => ['class' => 'pb-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::centered-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'pb-12']); ?>
        
        <a class="flex w-24 mt-5 px-3 py-2 bg-red-500 rounded-md text-white hover:cursor-pointer" href="<?php echo e(route('corporate.wallets.view', $coupon->wallet_id)); ?>">← Volver</a>

        <div class="max-w-md px-2 m-auto">
            <?php if (isset($component)) { $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063 = $component; } ?>
<?php $component = App\View\Components\Coupon::resolve(['id' => ''.e($coupon->id).'#','type' => ''.e($coupon->type).'','tag' => ''.e($coupon->tag).'','valid' => 'Consulte validez en interior'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('coupon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Coupon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => ''.e($coupon->image).'']); ?>
    
                 <?php $__env->slot('image', null, []); ?> 
                    <?php echo e($coupon->image); ?>

                 <?php $__env->endSlot(); ?>
    
                <?php echo e($coupon->name); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063)): ?>
<?php $component = $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063; ?>
<?php unset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063); ?>
<?php endif; ?>

        </div>
        
        <form action="<?php echo e(route('corporate.coupons.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="max-w-lg px-2 m-auto">
                <?php if(session('status')): ?>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.alert','data' => ['type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error']); ?>
                        <?php echo e(session('status')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <?php endif; ?>
                <input type="hidden" name="id" value="<?php echo e($coupon->id); ?>">

                <p class="mt-5 mb-2 font-semibold text-xl">Días de validez</p>
                <div class="grid grid-cols-7 mb-5">
    
                    <label for="day1" class="text-center select-none">Lunes</label>
                    <label for="day2" class="text-center select-none">Martes</label>
                    <label for="day3" class="text-center select-none">Miercoles</label>
                    <label for="day4" class="text-center select-none">Jueves</label>
                    <label for="day5" class="text-center select-none">Viernes</label>
                    <label for="day6" class="text-center select-none">Sábado</label>
                    <label for="day7" class="text-center select-none">Domingo</label>
    
                    <div class="inline-block m-auto">
                        <input
                            id="day1"
                            class="relative float-left mt-[0.15rem] p-4 rounded-[35%] border-[0.125rem] border-solid border-neutral-300 hover:cursor-pointer"
                            type="checkbox"
                            name="is_valid_monday"
                            value="1"
                            <?php echo e(! $coupon->is_valid_monday ?: 'checked'); ?>/>
                    </div>
                    <div class="inline-block m-auto">
                        <input
                            id="day2"
                            class="relative float-left mt-[0.15rem] p-4 rounded-[35%] border-[0.125rem] border-solid border-neutral-300 hover:cursor-pointer"
                            type="checkbox"
                            name="is_valid_tuesday"
                            value="1"
                            <?php echo e(! $coupon->is_valid_tuesday ?: 'checked'); ?>/>
                    </div>
                    <div class="inline-block m-auto">
                        <input
                            id="day3"
                            class="relative float-left mt-[0.15rem] p-4 rounded-[35%] border-[0.125rem] border-solid border-neutral-300 hover:cursor-pointer"
                            type="checkbox"
                            name="is_valid_wednesday"
                            value="1"
                            <?php echo e(! $coupon->is_valid_wednesday ?: 'checked'); ?>/>
                    </div>
                    <div class="inline-block m-auto">
                        <input
                            id="day4"
                            class="relative float-left mt-[0.15rem] p-4 rounded-[35%] border-[0.125rem] border-solid border-neutral-300 hover:cursor-pointer"
                            type="checkbox"
                            name="is_valid_thursday"
                            value="1"
                            <?php echo e(! $coupon->is_valid_thursday ?: 'checked'); ?>/>
                    </div>
                    <div class="inline-block m-auto">
                        <input
                            id="day5"
                            class="relative float-left mt-[0.15rem] p-4 rounded-[35%] border-[0.125rem] border-solid border-neutral-300 hover:cursor-pointer"
                            type="checkbox"
                            name="is_valid_friday"
                            value="1"
                            <?php echo e(! $coupon->is_valid_friday ?: 'checked'); ?>/>
                    </div>
                    <div class="inline-block m-auto">
                        <input
                            id="day6"
                            class="relative float-left mt-[0.15rem] p-4 rounded-[35%] border-[0.125rem] border-solid border-neutral-300 hover:cursor-pointer"
                            type="checkbox"
                            name="is_valid_saturday"
                            value="1"
                            <?php echo e(! $coupon->is_valid_saturday ?: 'checked'); ?>/>
                    </div>
                    <div class="inline-block m-auto">
                        <input
                            id="day7"
                            class="relative float-left mt-[0.15rem] p-4 rounded-[35%] border-[0.125rem] border-solid border-neutral-300 hover:cursor-pointer"
                            type="checkbox"
                            name="is_valid_sunday"
                            value="1"
                            <?php echo e(! $coupon->is_valid_sunday ?: 'checked'); ?>/>
                    </div>
                  
                </div>
    
                <p class="mt-5 mb-2 font-semibold text-xl">Duración de campaña</p>
                <div class="grid grid-cols-2">
                    <label class="ml-4 select-none" for="campain_starts">Inicio</label>
                    <label class="ml-4 select-none" for="campain_finishes">Acaba</label>
                    <input class="mx-2" type="date" name="campain_starts" id="campain_starts" value="<?php echo e($coupon->campain_starts); ?>">
                    <input class="mx-2" type="date" name="campain_finishes" id="campain_finishes" value="<?php echo e($coupon->campain_finishes); ?>">
                </div>
    
                <p class="mt-5 mb-2 font-semibold text-xl">Visibilidad</p>            
                    <input
                        id="is_active"
                        class="relative float-left mt-[0.15rem] p-2.5 rounded-[35%] border-[0.125rem] border-solid border-gray-700 bg-red-200 text-green-600 hover:cursor-pointer"
                        type="checkbox"
                        name="is_active"
                        value="1"
                        <?php echo e(! $coupon->is_active ?: 'checked'); ?>/>
                    <label for="is_active" class="ml-1 text-lg">Hacer público</label>

                <input
                    type="submit"
                    class="flex w-full my-5 px-3 py-2 bg-red-500 rounded-md text-white hover:cursor-pointer"
                    value="Guardar">
    
            </div>
        </form>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\resources\views/admin/coupons/edit.blade.php ENDPATH**/ ?>