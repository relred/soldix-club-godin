<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'number' => '',
    'label_position' => 'top',
    'labelPosition' => 'top',
    'icon_position' => 'left',
    'iconPosition' => 'left',
    'currency_position' => 'left',
    'currencyPosition' => 'left',
    'label' => '',
    'icon' => '',
    'currency' => '',
    'show_spinner' => false,
    'showSpinner' => false,
    'has_shadow' => true,
    'hasShadow' => true,
    'class' => '',
    'number_css' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'number' => '',
    'label_position' => 'top',
    'labelPosition' => 'top',
    'icon_position' => 'left',
    'iconPosition' => 'left',
    'currency_position' => 'left',
    'currencyPosition' => 'left',
    'label' => '',
    'icon' => '',
    'currency' => '',
    'show_spinner' => false,
    'showSpinner' => false,
    'has_shadow' => true,
    'hasShadow' => true,
    'class' => '',
    'number_css' => '',
]); ?>
<?php foreach (array_filter(([
    'number' => '',
    'label_position' => 'top',
    'labelPosition' => 'top',
    'icon_position' => 'left',
    'iconPosition' => 'left',
    'currency_position' => 'left',
    'currencyPosition' => 'left',
    'label' => '',
    'icon' => '',
    'currency' => '',
    'show_spinner' => false,
    'showSpinner' => false,
    'has_shadow' => true,
    'hasShadow' => true,
    'class' => '',
    'number_css' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php 
    // reset variables for Laravel 8 support
    $show_spinner = filter_var($show_spinner, FILTER_VALIDATE_BOOLEAN);
    $showSpinner = filter_var($showSpinner, FILTER_VALIDATE_BOOLEAN);
    $has_shadow = filter_var($has_shadow, FILTER_VALIDATE_BOOLEAN);
    $hasShadow = filter_var($hasShadow, FILTER_VALIDATE_BOOLEAN);
    if ($labelPosition !== $label_position) $label_position = $labelPosition;
    if ($iconPosition !== $icon_position) $icon_position = $iconPosition;
    if ($currencyPosition !== $currency_position) $currency_position = $currencyPosition;
    if ($showSpinner) $show_spinner = $showSpinner;
    if (!$hasShadow) $has_shadow = $hasShadow;
?>

    <div class="bw-statistic bg-white p-6 rounded-sm relative <?php if($has_shadow): ?>shadow-2xl shadow-gray-200/40 <?php endif; ?><?php echo e($class); ?>">
        <div class="flex space-x-4">
            <?php if($icon !== '' && $icon_position=='left'): ?>
            <div class="grow-0 icon"><?php echo $icon; ?></div>
            <?php endif; ?>
            <div class="grow number">
                <?php if($label_position=='top'): ?>
                <div class="uppercase tracking-wide text-xs text-gray-500/90 mb-1 label"><?php echo $label; ?></div>
                <?php endif; ?>
                <div class="text-3xl text-gray-500/90 font-light">
                    <?php if($show_spinner): ?><?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.spinner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php endif; ?>
                    <?php if($currency!=='' && $currency_position == 'left'): ?> <span class="text-gray-300 text-2xl"><?php echo $currency; ?></span><?php endif; ?><span class="figure tracking-wider <?php echo e($number_css); ?>"><?php echo e($number); ?></span><?php if($currency!=='' && $currency_position == 'right'): ?> <span class="text-gray-300 text-2xl"><?php echo $currency; ?></span><?php endif; ?>
                </div>
                <?php if($label_position=='bottom'): ?>
                <div class="uppercase tracking-wide text-xs text-gray-500/90 mt-1 label"><?php echo $label; ?></div>
                <?php endif; ?>
                <?php echo e($slot); ?>

            </div>
            <?php if($icon !== '' && $icon_position=='right'): ?>
            <div class="grow-0 icon"><?php echo $icon; ?></div>
            <?php endif; ?>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\vendor\mkocansey\bladewind\src/../resources/views/components/statistic.blade.php ENDPATH**/ ?>