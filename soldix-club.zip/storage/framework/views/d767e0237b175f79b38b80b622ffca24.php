<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Mis cupones')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.centered-content','data' => ['class' => 'sm:mt-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::centered-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'sm:mt-6']); ?>
        <div class="grid sm:grid-cols-2 pb-16">
            <?php if (isset($component)) { $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063 = $component; } ?>
<?php $component = App\View\Components\Coupon::resolve(['id' => '','type' => 'discount_percent','tag' => '40','valid' => 'Todos los martes'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('coupon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Coupon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('image', null, []); ?> 
                    https://res.cloudinary.com/de6hiq5n4/image/upload/v1683075785/assets/soldix/dummy%20images/t_ht9sxf.jpg
                 <?php $__env->endSlot(); ?>
                Descuento en hamburguesa la compra de un combo especial.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063)): ?>
<?php $component = $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063; ?>
<?php unset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063 = $component; } ?>
<?php $component = App\View\Components\Coupon::resolve(['id' => '','type' => '2x1','tag' => '2x1','valid' => 'Todos los días'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('coupon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Coupon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('image', null, []); ?> 
                    https://res.cloudinary.com/de6hiq5n4/image/upload/v1683075783/assets/soldix/dummy%20images/e_btrsri.webp
                 <?php $__env->endSlot(); ?>
                2x1 en la compra de cualquier bebida.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063)): ?>
<?php $component = $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063; ?>
<?php unset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063 = $component; } ?>
<?php $component = App\View\Components\Coupon::resolve(['id' => '','type' => 'discount_fixed','tag' => '20','valid' => 'Todos los días'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('coupon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Coupon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('image', null, []); ?> 
                    https://res.cloudinary.com/de6hiq5n4/image/upload/v1683075930/assets/soldix/dummy%20images/caffenio-768x768_gnh99u.jpg
                 <?php $__env->endSlot(); ?>
                20 Pesos de descuento en la compra de un café americano.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063)): ?>
<?php $component = $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063; ?>
<?php unset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063 = $component; } ?>
<?php $component = App\View\Components\Coupon::resolve(['id' => '','type' => 'free','tag' => 'Hamburguesa','valid' => 'Todos los días'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('coupon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Coupon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('image', null, []); ?> 
                    https://res.cloudinary.com/de6hiq5n4/image/upload/v1683075969/assets/soldix/dummy%20images/n_pr57qv.jpg
                 <?php $__env->endSlot(); ?>
                Hamburguesa con papas gratis en la compra de una del mismo tamaño.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063)): ?>
<?php $component = $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063; ?>
<?php unset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Productos-modernos\soldix-club\resources\views/user/index.blade.php ENDPATH**/ ?>