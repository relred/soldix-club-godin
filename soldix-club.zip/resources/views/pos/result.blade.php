<x-app-layout>

    <x-bladewind::centered-content>
        <x-bladewind::card class="mt-8 mx-3 lg:mx-0">
            <div class="grid grid-cols-2 text-center text-xl">
                <div class="m-2"> <span class="text-slate-500">Celular:</span> <span class="font-bold">Juan Sanchez</span></div>
                <div class="m-2"> <span class="text-slate-500">Celular:</span> <span class="font-bold">6862538728</span></div>
            </div>
        </x-bladewind::card>

        <x-bladewind::card class="text-center mt-8 mx-3 lg:mx-0">
            <p class="text-slate-400">Código de verificación:</p>
            <p class="text-5xl font-semibold">363</p>
        </x-bladewind::card>
    </x-bladewind::centered-content>

</x-app-layout>