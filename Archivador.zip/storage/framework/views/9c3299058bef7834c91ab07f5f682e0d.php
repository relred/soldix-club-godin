<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    // your table headers in <th></th> tags
    'header' => '',
    // setting to true will result in a striped table
    'striped' => config('bladewind.table.striped', false),
    // should the table with displayed with a drop-shadow effect
    'has_shadow' => config('bladewind.table.has_shadow', false),
    'hasShadow' => config('bladewind.table.has_shadow', false),
    // should the table have a border on all four sides
    'has_border' => config('bladewind.table.has_border', false),
    // should the table have row dividers
    'divided' => config('bladewind.table.divided', true),
    // if table has row dividers, how wide should they be
    // available value are regular, thin
    'divider' => config('bladewind.table.divider', 'regular'),
    // should rows light up on hover
    'hover_effect' => config('bladewind.table.hover_effect', true),
    'hoverEffect' => config('bladewind.table.hover_effect', true),
    // should the rows be tighter together
    'compact' => config('bladewind.table.compact', false),
    // provide a table name you can access via css
    'name' => 'tbl-'.uniqid(),
    'data' => null,
    'exclude_columns' => null,
    'include_columns' => null,
    'action_icons' => null,
    'actions_title' => 'actions',
    'column_aliases' => [],
    'searchable' => config('bladewind.table.searchable', false),
    'search_placeholder' => config('bladewind.table.search_placeholder', 'Search table below...'),
    'celled' => config('bladewind.table.celled', false),
    'uppercasing' => config('bladewind.table.uppercasing', true),
    'no_data_message' => config('bladewind.table.no_data_message', 'No records to display'),
    'message_as_empty_state' => config('bladewind.table.message_as_empty_state', false),
    // parameters expected by the empty state component ---------------
    'image' => asset('vendor/bladewind/images/empty-state.svg'),
    'heading' => '',
    'button_label' => '',
    'show_image' => config('bladewind.table.show_image', true),
    'onclick' => '',
    //------------------ end empty state parameters -------------------
    'selectable' => config('bladewind.table.selectable', false),
    'checkable' => config('bladewind.table.checkable', false),
    'transparent' => config('bladewind.table.transparent', false),
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    // your table headers in <th></th> tags
    'header' => '',
    // setting to true will result in a striped table
    'striped' => config('bladewind.table.striped', false),
    // should the table with displayed with a drop-shadow effect
    'has_shadow' => config('bladewind.table.has_shadow', false),
    'hasShadow' => config('bladewind.table.has_shadow', false),
    // should the table have a border on all four sides
    'has_border' => config('bladewind.table.has_border', false),
    // should the table have row dividers
    'divided' => config('bladewind.table.divided', true),
    // if table has row dividers, how wide should they be
    // available value are regular, thin
    'divider' => config('bladewind.table.divider', 'regular'),
    // should rows light up on hover
    'hover_effect' => config('bladewind.table.hover_effect', true),
    'hoverEffect' => config('bladewind.table.hover_effect', true),
    // should the rows be tighter together
    'compact' => config('bladewind.table.compact', false),
    // provide a table name you can access via css
    'name' => 'tbl-'.uniqid(),
    'data' => null,
    'exclude_columns' => null,
    'include_columns' => null,
    'action_icons' => null,
    'actions_title' => 'actions',
    'column_aliases' => [],
    'searchable' => config('bladewind.table.searchable', false),
    'search_placeholder' => config('bladewind.table.search_placeholder', 'Search table below...'),
    'celled' => config('bladewind.table.celled', false),
    'uppercasing' => config('bladewind.table.uppercasing', true),
    'no_data_message' => config('bladewind.table.no_data_message', 'No records to display'),
    'message_as_empty_state' => config('bladewind.table.message_as_empty_state', false),
    // parameters expected by the empty state component ---------------
    'image' => asset('vendor/bladewind/images/empty-state.svg'),
    'heading' => '',
    'button_label' => '',
    'show_image' => config('bladewind.table.show_image', true),
    'onclick' => '',
    //------------------ end empty state parameters -------------------
    'selectable' => config('bladewind.table.selectable', false),
    'checkable' => config('bladewind.table.checkable', false),
    'transparent' => config('bladewind.table.transparent', false),
]); ?>
<?php foreach (array_filter(([
    // your table headers in <th></th> tags
    'header' => '',
    // setting to true will result in a striped table
    'striped' => config('bladewind.table.striped', false),
    // should the table with displayed with a drop-shadow effect
    'has_shadow' => config('bladewind.table.has_shadow', false),
    'hasShadow' => config('bladewind.table.has_shadow', false),
    // should the table have a border on all four sides
    'has_border' => config('bladewind.table.has_border', false),
    // should the table have row dividers
    'divided' => config('bladewind.table.divided', true),
    // if table has row dividers, how wide should they be
    // available value are regular, thin
    'divider' => config('bladewind.table.divider', 'regular'),
    // should rows light up on hover
    'hover_effect' => config('bladewind.table.hover_effect', true),
    'hoverEffect' => config('bladewind.table.hover_effect', true),
    // should the rows be tighter together
    'compact' => config('bladewind.table.compact', false),
    // provide a table name you can access via css
    'name' => 'tbl-'.uniqid(),
    'data' => null,
    'exclude_columns' => null,
    'include_columns' => null,
    'action_icons' => null,
    'actions_title' => 'actions',
    'column_aliases' => [],
    'searchable' => config('bladewind.table.searchable', false),
    'search_placeholder' => config('bladewind.table.search_placeholder', 'Search table below...'),
    'celled' => config('bladewind.table.celled', false),
    'uppercasing' => config('bladewind.table.uppercasing', true),
    'no_data_message' => config('bladewind.table.no_data_message', 'No records to display'),
    'message_as_empty_state' => config('bladewind.table.message_as_empty_state', false),
    // parameters expected by the empty state component ---------------
    'image' => asset('vendor/bladewind/images/empty-state.svg'),
    'heading' => '',
    'button_label' => '',
    'show_image' => config('bladewind.table.show_image', true),
    'onclick' => '',
    //------------------ end empty state parameters -------------------
    'selectable' => config('bladewind.table.selectable', false),
    'checkable' => config('bladewind.table.checkable', false),
    'transparent' => config('bladewind.table.transparent', false),
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
    // reset variables for Laravel 8 support
    $has_shadow = filter_var($has_shadow, FILTER_VALIDATE_BOOLEAN);
    $hasShadow = filter_var($hasShadow, FILTER_VALIDATE_BOOLEAN);
    $hover_effect = filter_var($hover_effect, FILTER_VALIDATE_BOOLEAN);
    $hoverEffect = filter_var($hoverEffect, FILTER_VALIDATE_BOOLEAN);
    $striped = filter_var($striped, FILTER_VALIDATE_BOOLEAN);
    $compact = filter_var($compact, FILTER_VALIDATE_BOOLEAN);
    $divided = filter_var($divided, FILTER_VALIDATE_BOOLEAN);
    $searchable = filter_var($searchable, FILTER_VALIDATE_BOOLEAN);
    $uppercasing = filter_var($uppercasing, FILTER_VALIDATE_BOOLEAN);
    $celled = filter_var($celled, FILTER_VALIDATE_BOOLEAN);
    $selectable = filter_var($selectable, FILTER_VALIDATE_BOOLEAN);
    $checkable = filter_var($checkable, FILTER_VALIDATE_BOOLEAN);
    $transparent = filter_var($transparent, FILTER_VALIDATE_BOOLEAN);
    $message_as_empty_state = filter_var($message_as_empty_state, FILTER_VALIDATE_BOOLEAN);
    if ($hasShadow) $has_shadow = $hasShadow;
    if (!$hoverEffect) $hover_effect = $hoverEffect;
    $exclude_columns = !empty($exclude_columns) ? explode(',', str_replace(' ','', $exclude_columns)) : [];
    $action_icons = (!empty($action_icons)) ? ((is_array($action_icons)) ?
        $action_icons : json_decode(str_replace('&quot;', '"', $action_icons), true)) : [];
    $column_aliases = (!empty($column_aliases)) ? ((is_array($column_aliases)) ?
        $column_aliases : json_decode(str_replace('&quot;', '"', $column_aliases), true)) : [];
    $icons_array = [];

    if (!is_null($data)) {
        $data = (!is_array($data)) ? json_decode(str_replace('&quot;', '"', $data), true) : $data;
        $total_records = count($data);
        $table_headings = ($total_records > 0) ? array_keys((array) $data[0]) : [];

        if(!empty($exclude_columns)) {
            $table_headings = array_filter($table_headings,
            function($column) use ( $exclude_columns) {
                if(!in_array($column, $exclude_columns)) return $column;
            });
        }

        if( !empty($include_columns) ) {
            $table_headings = explode(',', str_replace(' ','', $include_columns));
        }

        // build action icons
        foreach ($action_icons as $action) {
            $action_array = explode('|',$action);
            $temp_actions_arr = [];
            foreach($action_array as $this_action){
                $action_str_to_arr = explode(':', $this_action);
                $temp_actions_arr[trim($action_str_to_arr[0])] = trim($action_str_to_arr[1]);
            }
            $icons_array[] = $temp_actions_arr;
        }

        if(!function_exists('build_click')){
            function build_click($click, $row_data){
                return preg_replace_callback('/{\w+}/', function ($matches) use ($row_data) {
                    foreach($matches as $match) {
                        return $row_data[str_replace('}', '', str_replace('{', '', $match))];
                    }
                }, $click);
            }
        }
    }
?>
<div class="<?php if($has_border && !$celled): ?> border border-gray-200/70 dark:border-dark-700/60 <?php endif; ?> border-collapse max-w-full">
    <div class="w-full">
        <?php if($searchable): ?>
            <div class="bw-table-filter-bar">
                <?php if (isset($component)) { $__componentOriginal399ab5ed63addab89395df8c37031002 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal399ab5ed63addab89395df8c37031002 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.input','data' => ['name' => 'bw-search-'.e($name).'','placeholder' => ''.e($search_placeholder).'','onkeyup' => 'filterTable(this.value, \'table.'.e($name).'\')','addClearing' => 'false','class' => '!mb-0 focus:!border-slate-300 !pl-9 !py-3','clearable' => 'true','prefixIsIcon' => 'true','prefix' => 'magnifying-glass']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bw-search-'.e($name).'','placeholder' => ''.e($search_placeholder).'','onkeyup' => 'filterTable(this.value, \'table.'.e($name).'\')','add_clearing' => 'false','class' => '!mb-0 focus:!border-slate-300 !pl-9 !py-3','clearable' => 'true','prefix_is_icon' => 'true','prefix' => 'magnifying-glass']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal399ab5ed63addab89395df8c37031002)): ?>
<?php $attributes = $__attributesOriginal399ab5ed63addab89395df8c37031002; ?>
<?php unset($__attributesOriginal399ab5ed63addab89395df8c37031002); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal399ab5ed63addab89395df8c37031002)): ?>
<?php $component = $__componentOriginal399ab5ed63addab89395df8c37031002; ?>
<?php unset($__componentOriginal399ab5ed63addab89395df8c37031002); ?>
<?php endif; ?>
            </div>
        <?php endif; ?>

        <table class="bw-table w-full <?php echo e($name); ?> <?php if($has_shadow): ?> drop-shadow shadow shadow-gray-200/70 dark:shadow-md dark:shadow-dark-950/20 <?php endif; ?>
            <?php if($divided): ?> divided <?php if($divider=='thin'): ?> thin <?php endif; ?> <?php endif; ?>  <?php if($striped): ?> striped <?php endif; ?>  <?php if($celled): ?> celled <?php endif; ?>
            <?php if($hover_effect): ?> with-hover-effect <?php endif; ?> <?php if($compact): ?> compact <?php endif; ?> <?php if($uppercasing): ?> uppercase-headers <?php endif; ?>
            <?php if($selectable): ?> selectable <?php endif; ?> <?php if($checkable): ?> checkable <?php endif; ?> <?php if($transparent): ?> transparent <?php endif; ?>">
            <?php if(is_null($data)): ?>
                <?php if(!empty($header)): ?>
                    <thead>
                    <tr><?php echo e($header); ?></tr> 
                    </thead>
                <?php endif; ?>
                <tbody><?php echo e($slot); ?></tbody>
            <?php else: ?>
                <thead>
                <tr>
                    <?php
                        // if there are no records, build the headings with $column_headings if the array exists
                        $table_headings = ($total_records>0) ? $table_headings : (($column_aliases) ?? []);
                    ?>
                    <?php $__currentLoopData = $table_headings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(str_replace('_',' ', $column_aliases[$th] ?? $th )); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if( !empty($action_icons)): ?>
                        <th class="!text-right"><?php echo e($actions_title); ?></th>
                    <?php endif; ?>
                </tr>
                </thead>
                <?php if($total_records > 0): ?>
                    <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-id="<?php echo e($row['id'] ?? uniqid()); ?>">
                            <?php $__currentLoopData = $table_headings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo $row[$th]; ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if( !empty($icons_array) ): ?>
                                <td class="text-right space-x-2 actions">
                                    <?php $__currentLoopData = $icons_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($icon['icon'])): ?>
                                            <?php if(!empty($icon['tip'])): ?>
                                                <a data-tooltip="<?php echo e($icon['tip']); ?>" data-inverted=""
                                                   data-position="top center"> <?php endif; ?>
                                                    <?php if (isset($component)) { $__componentOriginalb4077406ec1be740458fd4823e4ae997 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb4077406ec1be740458fd4823e4ae997 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.button.circle','data' => ['size' => 'tiny','icon' => ''.e($icon['icon']).'','color' => ''.e($icon['color'] ?? '').'','onclick' => ''.build_click($icon['click'], $row) ?? 'void(0)'.'','type' => ''.isset($icon['color']) ? 'primary' : 'secondary'.'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::button.circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'tiny','icon' => ''.e($icon['icon']).'','color' => ''.e($icon['color'] ?? '').'','onclick' => ''.build_click($icon['click'], $row) ?? 'void(0)'.'','type' => ''.isset($icon['color']) ? 'primary' : 'secondary'.'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb4077406ec1be740458fd4823e4ae997)): ?>
<?php $attributes = $__attributesOriginalb4077406ec1be740458fd4823e4ae997; ?>
<?php unset($__attributesOriginalb4077406ec1be740458fd4823e4ae997); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb4077406ec1be740458fd4823e4ae997)): ?>
<?php $component = $__componentOriginalb4077406ec1be740458fd4823e4ae997; ?>
<?php unset($__componentOriginalb4077406ec1be740458fd4823e4ae997); ?>
<?php endif; ?>
                                                    <?php if(!empty($icon['tip'])): ?>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?php echo e(count($table_headings)); ?>" class="text-center">
                                <?php if($message_as_empty_state): ?>
                                    <?php if (isset($component)) { $__componentOriginalf281e3dc0c95fa53b3a01b5aa409f51b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf281e3dc0c95fa53b3a01b5aa409f51b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.empty-state','data' => ['message' => $no_data_message,'buttonLabel' => $button_label,'onclick' => $onclick,'image' => $image,'showImage' => $show_image,'heading' => $heading]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($no_data_message),'button_label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($button_label),'onclick' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($onclick),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($image),'show_image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($show_image),'heading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($heading)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf281e3dc0c95fa53b3a01b5aa409f51b)): ?>
<?php $attributes = $__attributesOriginalf281e3dc0c95fa53b3a01b5aa409f51b; ?>
<?php unset($__attributesOriginalf281e3dc0c95fa53b3a01b5aa409f51b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf281e3dc0c95fa53b3a01b5aa409f51b)): ?>
<?php $component = $__componentOriginalf281e3dc0c95fa53b3a01b5aa409f51b; ?>
<?php unset($__componentOriginalf281e3dc0c95fa53b3a01b5aa409f51b); ?>
<?php endif; ?>
                                <?php else: ?>
                                    <?php echo e($no_data_message); ?>

                                <?php endif; ?>
                                <script>
                                    changeCss('.<?php echo e($name); ?>', 'with-hover-effect', 'remove');
                                    changeCss('.<?php echo e($name); ?>', 'has-no-data');
                                </script>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                <?php endif; ?>
        </table>
    </div>
</div>
<?php if($selectable): ?>
    <?php if (! $__env->hasRenderedOnce('18831b70-1424-4742-ba34-c76ceab15a10')): $__env->markAsRenderedOnce('18831b70-1424-4742-ba34-c76ceab15a10'); ?>
        <script>
            const addRemoveRowValue = (value, name) => {
                const input = domEl(`input[type="hidden"][name="${name}"]`);
                const table = domEl(`.bw-table.${name}.selectable`);
                const checkAllBox = table.querySelector('th:first-child input[type="checkbox"]');
                const partiallyCheckedBox = table.querySelector('th:first-child .check-icon');
                const totalRows = table.getAttribute('data-total-rows') * 1;
                let totalChecked = table.getAttribute('data-total-checked') * 1;
                if (value) {
                    if (input.value.includes(value)) { // remove
                        const keyword = `(,?)${value}`;
                        input.value = input.value.replace(input.value.match(keyword)[0], '');
                        totalChecked--;
                    } else { // add
                        input.value += `,${value}`;
                        totalChecked++;
                    }
                    table.setAttribute('data-total-checked', `${totalChecked}`);
                    if (totalChecked > 0 && totalChecked < totalRows) {
                        hide(checkAllBox, true);
                        unhide(partiallyCheckedBox, true);
                        if (!partiallyCheckedBox.getAttribute('onclick')) {
                            partiallyCheckedBox.setAttribute('onclick', `checkAllFromPartiallyChecked('${name}')`);
                        }
                    } else {
                        unhide(checkAllBox, true);
                        hide(partiallyCheckedBox, true);
                        checkAllBox.checked = (totalChecked === totalRows);
                    }
                    stripComma(input);
                }
            }

            const checkAllFromPartiallyChecked = (name) => {
                const table = domEl(`.bw-table.${name}.selectable`);
                const checkAllBox = table.querySelector('th:first-child input[type="checkbox"]')
                checkAllBox.checked = true;
                toggleAll(checkAllBox, `.bw-table.${name}`);
            }
        </script>
    <?php endif; ?>
    <script>
        dom_els('.bw-table.<?php echo e($name); ?>.selectable tr').forEach((el) => {
            el.addEventListener('click', (e) => {
                el.classList.toggle('selected');
                let id = el.getAttribute('data-id');
                let checkbox = el.querySelector('td:first-child input[type="checkbox"]');
                if (checkbox) checkbox.checked = el.classList.contains('selected');
                addRemoveRowValue(id, '<?php echo e($name); ?>');
            });
        });
    </script>
    <input type="hidden" name="<?php echo e($name); ?>" class="<?php echo e($name); ?>"/>
<?php endif; ?>

<?php if($checkable): ?>
    <?php if (! $__env->hasRenderedOnce('57dbfa3f-c9b7-48eb-afe1-332e58b928a8')): $__env->markAsRenderedOnce('57dbfa3f-c9b7-48eb-afe1-332e58b928a8'); ?>
        <div class="hidden size-0 checkbox-template">
            <?php if (isset($component)) { $__componentOriginal701009bc86ef91af6041f0e4d6588e8f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal701009bc86ef91af6041f0e4d6588e8f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.checkbox','data' => ['class' => '!size-5 !mr-0 rounded-md','labelCss' => 'mr-0','addClearing' => 'false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '!size-5 !mr-0 rounded-md','label_css' => 'mr-0','add_clearing' => 'false']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal701009bc86ef91af6041f0e4d6588e8f)): ?>
<?php $attributes = $__attributesOriginal701009bc86ef91af6041f0e4d6588e8f; ?>
<?php unset($__attributesOriginal701009bc86ef91af6041f0e4d6588e8f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal701009bc86ef91af6041f0e4d6588e8f)): ?>
<?php $component = $__componentOriginal701009bc86ef91af6041f0e4d6588e8f; ?>
<?php unset($__componentOriginal701009bc86ef91af6041f0e4d6588e8f); ?>
<?php endif; ?>
        </div>
        <div class="hidden size-0 partial-check-template">
            <?php if (isset($component)) { $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.icon','data' => ['name' => 'minus','type' => 'solid','class' => 'hidden stroke-2 rounded-md bg-primary-500 text-white check-icon !size-5 !mb-1 !mt-[4px] !-ml-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'minus','type' => 'solid','class' => 'hidden stroke-2 rounded-md bg-primary-500 text-white check-icon !size-5 !mb-1 !mt-[4px] !-ml-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $attributes = $__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__attributesOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386)): ?>
<?php $component = $__componentOriginalf9f835f724769f9dbaf9518fdb1e6386; ?>
<?php unset($__componentOriginalf9f835f724769f9dbaf9518fdb1e6386); ?>
<?php endif; ?>
        </div>
        <script>
            const addCheckboxesToTable = (el) => {
                let table = domEl(el);
                let checkboxHtml = domEl('.checkbox-template').innerHTML;
                let partialCheckHtml = domEl('.partial-check-template').innerHTML;

                for (let row of table.rows) {
                    let cellTag = (row.parentElement.tagName.toLowerCase() === 'thead') ? 'th' : 'td';
                    let checkboxCell = document.createElement(cellTag);
                    checkboxCell.innerHTML = (cellTag === 'th') ?
                        checkboxHtml.replace('type="checkbox"', `type="checkbox" onclick="toggleAll(this,'${el}')"`) + partialCheckHtml :
                        checkboxHtml;
                    checkboxCell.setAttribute('class', '!size-0 !pr-0');
                    row.insertBefore(checkboxCell, row.firstChild);
                }
                table.setAttribute('data-total-rows', (table.rows.length - 1)); // minus heading
                table.setAttribute('data-total-checked', 0);
            }

            const toggleAll = (srcEl, table) => {
                dom_els(`${table}.selectable tr`).forEach((el) => {
                    const checkbox = el.querySelector('td:first-child input[type="checkbox"]');
                    if (checkbox) {
                        // to properly take advantage of the logic for adding and removing IDs
                        // already defined in addRemoveRowValue(), simply simulate a click of the checkbox
                        if (srcEl.checked && !checkbox.checked || (!srcEl.checked && checkbox.checked)) el.click();
                    }
                });
            }

        </script>
    <?php endif; ?>
    <script>
        addCheckboxesToTable('.bw-table.<?php echo e($name); ?>');
    </script>
<?php endif; ?><?php /**PATH /home/dainamo/proyectos/soldix-club-cuidadores/vendor/mkocansey/bladewind/src/../resources/views/components/table.blade.php ENDPATH**/ ?>