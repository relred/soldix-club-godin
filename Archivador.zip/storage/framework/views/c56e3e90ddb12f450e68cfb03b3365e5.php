<div class="w-full max-w-6xl rounded bg-white shadow-xl mt-5 p-10 lg:p-20 mx-auto text-gray-800 relative md:text-left">
    <?php if($status): ?>
        <?php if (isset($component)) { $__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.alert','data' => ['showCloseIcon' => 'false','type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['showCloseIcon' => 'false','type' => 'success']); ?>
            <?php echo e($status); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0)): ?>
<?php $attributes = $__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0; ?>
<?php unset($__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0)): ?>
<?php $component = $__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0; ?>
<?php unset($__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0); ?>
<?php endif; ?>
    <?php endif; ?>

    <div class="grid w-full place-items-center mt-2 mb-6">
        <p class="text-center mb-3 font-bold text-lg text-neutral-600">Tipo de descuento</p>
        <div class="grid w-[40rem] grid-cols-4 gap-2 rounded-xl bg-gray-200 p-2">
            <div>
                <input type="radio" id="discount_fixed" name="type" value="discount_fixed" wire:model="type" class="peer hidden" checked />
                <label wire:click="unset_tag" for="discount_fixed" class="block cursor-pointer select-none rounded-xl p-2 text-center peer-checked:bg-red-500 peer-checked:font-bold peer-checked:text-white">Fijo</label>
            </div>
    
            <div>
                <input type="radio" id="discount_percent" name="type" value="discount_percent" wire:model="type" class="peer hidden" />
                <label wire:click="unset_tag" for="discount_percent" class="block cursor-pointer select-none rounded-xl p-2 text-center peer-checked:bg-red-500 peer-checked:font-bold peer-checked:text-white">Porcentual</label>
            </div>
    
            <div>
                <input type="radio" id="free" name="type" value="free" wire:model="type" class="peer hidden" />
                <label wire:click="unset_tag" for="free" class="block cursor-pointer select-none rounded-xl p-2 text-center peer-checked:bg-red-500 peer-checked:font-bold peer-checked:text-white">Producto Gratis</label>
            </div>
    
            <div>
                <input type="radio" id="2x1" name="type" value="2x1" wire:model="type" class="peer hidden" />
                <label wire:click="unset_tag" for="2x1" class="block cursor-pointer select-none rounded-xl p-2 text-center peer-checked:bg-red-500 peer-checked:font-bold peer-checked:text-white">2x1</label>
            </div>
        </div>
    </div>

    <div class="md:flex items-center -mx-10">
        <div class="w-full md:w-1/2 mb-10 md:mb-0">
            <?php if (isset($component)) { $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b17bc6b1116010ab15bd6a7841f2063 = $attributes; } ?>
<?php $component = App\View\Components\Coupon::resolve(['id' => '','type' => ''.e($type).'','tag' => ''.e($tag).'','valid' => 'Días de validez en interior'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('coupon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Coupon::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => ''.e($image).'']); ?>
                <?php if($name): ?>
                    <?php echo e($name); ?>

                <?php else: ?>
                    Descuento en hamburguesa la compra de un combo especial.
                <?php endif; ?>
                 <?php $__env->slot('image', null, []); ?> 
                    <?php if($image): ?>
                        <?php echo e($image->temporaryUrl()); ?>

                    <?php else: ?>
                        <?php echo e('https://res.cloudinary.com/de6hiq5n4/image/upload/v1683075785/assets/soldix/dummy%20images/t_ht9sxf.jpg'); ?>

                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b17bc6b1116010ab15bd6a7841f2063)): ?>
<?php $attributes = $__attributesOriginal4b17bc6b1116010ab15bd6a7841f2063; ?>
<?php unset($__attributesOriginal4b17bc6b1116010ab15bd6a7841f2063); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063)): ?>
<?php $component = $__componentOriginal4b17bc6b1116010ab15bd6a7841f2063; ?>
<?php unset($__componentOriginal4b17bc6b1116010ab15bd6a7841f2063); ?>
<?php endif; ?>
        </div>
        <div class="w-full md:w-1/2 px-10">
            <p class="text-center mb-3 font-bold text-lg text-neutral-600">Información de cupón</p>
            <div class="mb-5">
                <input
                    type="text"
                    id="name"
                    placeholder="Título"
                    class="w-full rounded-sm border border-[#e0e0e0] bg-white mb-0.5 py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
                    wire:model.debounce.5ms="name"
                />

                <?php if($type == '2x1'): ?>
                    <div class="grid grid-cols-3">
                        <input
                            type="text"
                            id="tag"
                            name="tag"
                            class="w-full rounded-sm border border-[#e0e0e0] bg-white mb-0.5 py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
                            wire:model.debounce.5ms="first2x1"
                        />
                        <p class="text-center font-bold text-gray-500 text-2xl mt-2">x</p>
                        <input
                            type="text"
                            id="tag"
                            name="tag"
                            class="w-full rounded-sm border border-[#e0e0e0] bg-white mb-0.5 py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
                            wire:model.debounce.5ms="second2x1"
                        />
                    </div>
                <?php elseif($type == 'free'): ?>
                    <input
                        type="text"
                        id="tag"
                        name="tag"
                        placeholder="Producto"
                        class="w-full rounded-sm border border-[#e0e0e0] bg-white mb-0.5 py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
                        wire:model.debounce.5ms="tag"
                    />
                <?php elseif($type == 'discount_fixed'): ?>
                    <input
                        type="number"
                        id="tag"
                        name="tag"
                        placeholder="Descuento en pesos"
                        class="w-full rounded-sm border border-[#e0e0e0] bg-white mb-0.5 py-3 px-6 text-base font-medium text-[#6B7280] text-center outline-none focus:border-[#6A64F1] focus:shadow-md"
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/^0[^.]/, '0');"
                        wire:model.debounce.5ms="tag"
                    />
                <?php else: ?>
                    <input
                        type="number"
                        id="tag"
                        name="tag"
                        placeholder="Porcentaje de descuento"
                        class="w-full rounded-sm border border-[#e0e0e0] bg-white mb-0.5 py-3 px-6 text-base font-medium text-[#6B7280] text-center outline-none focus:border-[#6A64F1] focus:shadow-md"
                        oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/^0[^.]/, '0');"
                        wire:model.debounce.5ms="tag"
                    />
                <?php endif; ?>
    
                <div class="mb-0.5">
                    <input type="file" wire:model="image" id="file" class="sr-only" />
                    <label
                      for="file"
                      class="relative flex min-h-[200px] items-center justify-center rounded-md border border-dashed border-[#e0e0e0] px-12 text-center"
                    >
                    <div>
                        <span class="mb-2 block text-xl font-semibold text-[#07074D] rounded border border-[#e0e0e0] py-2 px-7">
                            Seleccione una imagen
                        </span>
                    </div>
                    </label>
                </div>
            </div>


            <input
                wire:click="store(<?php echo e($wallet_id); ?>)"
                wire:loading.remove
                wire:target="image, store"
                type="submit"
                class="flex w-full my-5 px-3 py-2 bg-red-500 rounded-md text-white hover:cursor-pointer" 
                value="Registrar">

            <div class="text-center my-5" wire:loading.block wire:target="image, store">
                <?php if (isset($component)) { $__componentOriginal0285c67f0472b8447eb8291a5277f908 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0285c67f0472b8447eb8291a5277f908 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.spinner','data' => ['class' => 'text-center','size' => 'medium']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center','size' => 'medium']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0285c67f0472b8447eb8291a5277f908)): ?>
<?php $attributes = $__attributesOriginal0285c67f0472b8447eb8291a5277f908; ?>
<?php unset($__attributesOriginal0285c67f0472b8447eb8291a5277f908); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0285c67f0472b8447eb8291a5277f908)): ?>
<?php $component = $__componentOriginal0285c67f0472b8447eb8291a5277f908; ?>
<?php unset($__componentOriginal0285c67f0472b8447eb8291a5277f908); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/dainamo/proyectos/soldix-club-cuidadores/resources/views/livewire/add-coupon.blade.php ENDPATH**/ ?>