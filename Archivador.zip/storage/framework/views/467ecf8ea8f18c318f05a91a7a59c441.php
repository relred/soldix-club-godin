<div>
    <div class="mb-0.5">
        <p class="text-lg ml-2 mb-2 font-semibold">Imagen (Opcional)</p>

        <input type="file" name="file" id="file" class="sr-only" wire:model="image" />
        <label
            for="file"
            class="relative flex min-h-[200px] bg-gray-50 items-center justify-center rounded-md border border-dashed border-[#e0e0e0] px-12 text-center"
            >
        <div>
            <span class="mb-2 block text-xl font-semibold text-[#07074D] rounded border border-[#e0e0e0] py-2 px-7">
                Seleccione una imagen
            </span>
        </div>
        </label>

        <?php if($image): ?>
            <div class="my-3">
                <img class="max-h-32" src="<?php echo e($image->temporaryUrl()); ?>" alt="">
            </div>
        <?php endif; ?>

    </div>

    <div class="text-center">
        <input 
            wire:loading.remove
            type="submit" 
            class="flex my-5 ml-2 px-3 py-2 bg-red-500 rounded-md text-white" 
            value="Registrar">
    </div>

    <div class="mx-10 my-5" wire:loading.block wire:target="image, store">
        <?php if (isset($component)) { $__componentOriginal0285c67f0472b8447eb8291a5277f908 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0285c67f0472b8447eb8291a5277f908 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.spinner','data' => ['class' => 'text-center','size' => 'medium']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-center','size' => 'medium']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0285c67f0472b8447eb8291a5277f908)): ?>
<?php $attributes = $__attributesOriginal0285c67f0472b8447eb8291a5277f908; ?>
<?php unset($__attributesOriginal0285c67f0472b8447eb8291a5277f908); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0285c67f0472b8447eb8291a5277f908)): ?>
<?php $component = $__componentOriginal0285c67f0472b8447eb8291a5277f908; ?>
<?php unset($__componentOriginal0285c67f0472b8447eb8291a5277f908); ?>
<?php endif; ?>
    </div>
</div><?php /**PATH /home/dainamo/proyectos/soldix-club-cuidadores/resources/views/livewire/add-brand.blade.php ENDPATH**/ ?>