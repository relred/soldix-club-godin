<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Administradores')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal44c40385a931f546568e2a429adc3059 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal44c40385a931f546568e2a429adc3059 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.centered-content','data' => ['class' => 'py-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::centered-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'py-12']); ?>

        <?php if (isset($component)) { $__componentOriginal92c649acd7dec03de4c2233151f407ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92c649acd7dec03de4c2233151f407ba = $attributes; } ?>
<?php $component = App\View\Components\InputAlerts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-alerts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputAlerts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92c649acd7dec03de4c2233151f407ba)): ?>
<?php $attributes = $__attributesOriginal92c649acd7dec03de4c2233151f407ba; ?>
<?php unset($__attributesOriginal92c649acd7dec03de4c2233151f407ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92c649acd7dec03de4c2233151f407ba)): ?>
<?php $component = $__componentOriginal92c649acd7dec03de4c2233151f407ba; ?>
<?php unset($__componentOriginal92c649acd7dec03de4c2233151f407ba); ?>
<?php endif; ?>

        <?php if(auth()->user()->is_local_admin): ?>
            <button onclick="showModal('register')" class="flex mb-5 ml-2 px-3 py-2 bg-red-500 rounded-md text-white">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user-plus mr-1" width="20" height="25" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <circle cx="12" cy="12" r="9" />
                    <line x1="9" y1="12" x2="15" y2="12" />
                    <line x1="12" y1="9" x2="12" y2="15" />
                </svg>
                Agregar
            </button>                
        <?php else: ?>
            <p class="mb-2 text-sm font-semibold text-gray-600">Sólo super admin puede agregar nuevos administradores.</p>
        <?php endif; ?>


        <?php if (isset($component)) { $__componentOriginalfec749cfb1ffd5ad42691601346ccfd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.table','data' => ['hasShadow' => 'true','striped' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hasShadow' => 'true','striped' => 'true']); ?>

             <?php $__env->slot('header', null, []); ?> 
                <th>Usuario</th>
                <th><span class="float-right">Acciones</span> </th>
             <?php $__env->endSlot(); ?>

            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div class="ml-3">
                            <div class="text-sm font-medium text-slate-900">
                                <?php echo e($admin->name); ?>

                            </div>
                            <div class="text-sm text-slate-500 truncate">
                                <?php echo e($admin->username); ?>

                            </div>
                        </div>
                    </td>
                    <td>
                        <?php if(auth()->user()->is_local_admin): ?>
                            <form action="<?php echo e(route('admin.destroy',[$admin->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="flex float-right px-3 py-2 bg-red-500 rounded-md text-white mx-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-trash" width="22" height="22" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                        <path d="M4 7l16 0" />
                                        <path d="M10 11l0 6" />
                                        <path d="M14 11l0 6" />
                                        <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" />
                                        <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" />
                                    </svg>
                                </button>
                            </form>                                
                        <?php endif; ?>
                        <button onclick="showModal('profile')" class="flex float-right px-3 py-2 bg-blue-500 rounded-md text-white mx-1">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user" width="22" height="22" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0" />
                                <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" />
                            </svg>
                        </button>
                    </td>    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7)): ?>
<?php $attributes = $__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7; ?>
<?php unset($__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfec749cfb1ffd5ad42691601346ccfd7)): ?>
<?php $component = $__componentOriginalfec749cfb1ffd5ad42691601346ccfd7; ?>
<?php unset($__componentOriginalfec749cfb1ffd5ad42691601346ccfd7); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal44c40385a931f546568e2a429adc3059)): ?>
<?php $attributes = $__attributesOriginal44c40385a931f546568e2a429adc3059; ?>
<?php unset($__attributesOriginal44c40385a931f546568e2a429adc3059); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal44c40385a931f546568e2a429adc3059)): ?>
<?php $component = $__componentOriginal44c40385a931f546568e2a429adc3059; ?>
<?php unset($__componentOriginal44c40385a931f546568e2a429adc3059); ?>
<?php endif; ?>


    <?php if (isset($component)) { $__componentOriginalc5c12b36d74c6daf50fd7453ed806164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal','data' => ['title' => 'Agregar Nuevo Administrador','name' => 'register','size' => 'large','centerActionButtons' => 'false','okButtonLabel' => '','cancelButtonLabel' => 'Cerrar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar Nuevo Administrador','name' => 'register','size' => 'large','centerActionButtons' => 'false','okButtonLabel' => '','cancelButtonLabel' => 'Cerrar']); ?>
        <hr class="mb-7 mt-1">
        <form action="<?php echo e(route('admin.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginal405a67563ffd994716cfbe38d0ede7bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal405a67563ffd994716cfbe38d0ede7bf = $attributes; } ?>
<?php $component = App\View\Components\InputBlock::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputBlock::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'name','placeholder' => 'Ej. Hector Sánchez Gomez','value' => ''.e(old('name')).'','required' => true]); ?>
                Nombre 
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal405a67563ffd994716cfbe38d0ede7bf)): ?>
<?php $attributes = $__attributesOriginal405a67563ffd994716cfbe38d0ede7bf; ?>
<?php unset($__attributesOriginal405a67563ffd994716cfbe38d0ede7bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal405a67563ffd994716cfbe38d0ede7bf)): ?>
<?php $component = $__componentOriginal405a67563ffd994716cfbe38d0ede7bf; ?>
<?php unset($__componentOriginal405a67563ffd994716cfbe38d0ede7bf); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal405a67563ffd994716cfbe38d0ede7bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal405a67563ffd994716cfbe38d0ede7bf = $attributes; } ?>
<?php $component = App\View\Components\InputBlock::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputBlock::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'username','placeholder' => 'Ej. hsanchez','pattern' => '[a-z0-9]{3,16}','title' => 'No puede contener espacios, mayúsculas o simbolos, y debe tener al menos 3 caracteres un máximo de 16','value' => ''.e(old('username')).'','required' => true]); ?>
                Usuario 
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal405a67563ffd994716cfbe38d0ede7bf)): ?>
<?php $attributes = $__attributesOriginal405a67563ffd994716cfbe38d0ede7bf; ?>
<?php unset($__attributesOriginal405a67563ffd994716cfbe38d0ede7bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal405a67563ffd994716cfbe38d0ede7bf)): ?>
<?php $component = $__componentOriginal405a67563ffd994716cfbe38d0ede7bf; ?>
<?php unset($__componentOriginal405a67563ffd994716cfbe38d0ede7bf); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal405a67563ffd994716cfbe38d0ede7bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal405a67563ffd994716cfbe38d0ede7bf = $attributes; } ?>
<?php $component = App\View\Components\InputBlock::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputBlock::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'password','name' => 'password','placeholder' => '*********','required' => true]); ?>
                Contraseña 
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal405a67563ffd994716cfbe38d0ede7bf)): ?>
<?php $attributes = $__attributesOriginal405a67563ffd994716cfbe38d0ede7bf; ?>
<?php unset($__attributesOriginal405a67563ffd994716cfbe38d0ede7bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal405a67563ffd994716cfbe38d0ede7bf)): ?>
<?php $component = $__componentOriginal405a67563ffd994716cfbe38d0ede7bf; ?>
<?php unset($__componentOriginal405a67563ffd994716cfbe38d0ede7bf); ?>
<?php endif; ?>

            <?php if(auth()->user()->is_local_admin): ?>
            <p class="text-lg ml-2 font-semibold">Tipo de usuario</p>
            <div>
                <input type="radio" name="is_local_admin" id="admin" class="peer hidden" checked value="0" />
                <label for="admin" class="block cursor-pointer select-none rounded-xl p-2 text-center peer-checked:bg-blue-500 peer-checked:font-bold peer-checked:text-white">
                  Admin
                </label>
            </div>
          
            <div>
                <input type="radio" name="is_local_admin" id="superadmin" class="peer hidden" value="1"/>
                <label for="superadmin" class="block cursor-pointer select-none rounded-xl p-2 text-center peer-checked:bg-red-500 peer-checked:font-bold peer-checked:text-white">
                  Super Admin
                </label>
            </div>
            <?php endif; ?>

            <input 
                type="submit" 
                class="flex my-5 ml-2 px-3 py-2 bg-red-500 rounded-md text-white" 
                value="Registrar">

        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $attributes = $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $component = $__componentOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc5c12b36d74c6daf50fd7453ed806164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal','data' => ['title' => 'Perfil','name' => 'profile','size' => 'xl','okButtonLabel' => '','cancelButtonLabel' => 'Cerrar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Perfil','name' => 'profile','size' => 'xl','okButtonLabel' => '','cancelButtonLabel' => 'Cerrar']); ?>

        <div class="flex">
            <div class="flex-none w-48 lg:w-64 m-2 text-center">
                <?php if (isset($component)) { $__componentOriginal0ad07d55369c3f142811e8f2e87d048d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.avatar','data' => ['image' => 'https://res.cloudinary.com/de6hiq5n4/image/upload/v1676696051/jsulpbuflhqzoul3qcaz.jpg','size' => 'omg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'https://res.cloudinary.com/de6hiq5n4/image/upload/v1676696051/jsulpbuflhqzoul3qcaz.jpg','size' => 'omg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $attributes = $__attributesOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__attributesOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d)): ?>
<?php $component = $__componentOriginal0ad07d55369c3f142811e8f2e87d048d; ?>
<?php unset($__componentOriginal0ad07d55369c3f142811e8f2e87d048d); ?>
<?php endif; ?>
            </div>
            <div class="flex-1 m-2">
                <?php if (isset($component)) { $__componentOriginal52e9ac57da4d5b885edbde6e81bcb2e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52e9ac57da4d5b885edbde6e81bcb2e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.list-view','data' => ['transparent' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::list-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['transparent' => 'true']); ?>

                    <?php if (isset($component)) { $__componentOriginal737c823632bf2c76432c6a15bfcf7ad4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.list-item','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::list-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

                        <div class="text-sm font-medium text-slate-900">
                            Michael K. Ocansey
                        </div>
                
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4)): ?>
<?php $attributes = $__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4; ?>
<?php unset($__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal737c823632bf2c76432c6a15bfcf7ad4)): ?>
<?php $component = $__componentOriginal737c823632bf2c76432c6a15bfcf7ad4; ?>
<?php unset($__componentOriginal737c823632bf2c76432c6a15bfcf7ad4); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal737c823632bf2c76432c6a15bfcf7ad4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.list-item','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::list-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div class="text-sm font-medium text-slate-900">
                            Michael K. Ocansey
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4)): ?>
<?php $attributes = $__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4; ?>
<?php unset($__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal737c823632bf2c76432c6a15bfcf7ad4)): ?>
<?php $component = $__componentOriginal737c823632bf2c76432c6a15bfcf7ad4; ?>
<?php unset($__componentOriginal737c823632bf2c76432c6a15bfcf7ad4); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal737c823632bf2c76432c6a15bfcf7ad4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.list-item','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::list-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <div class="text-sm font-medium text-slate-900">
                            Michael K. Ocansey
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4)): ?>
<?php $attributes = $__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4; ?>
<?php unset($__attributesOriginal737c823632bf2c76432c6a15bfcf7ad4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal737c823632bf2c76432c6a15bfcf7ad4)): ?>
<?php $component = $__componentOriginal737c823632bf2c76432c6a15bfcf7ad4; ?>
<?php unset($__componentOriginal737c823632bf2c76432c6a15bfcf7ad4); ?>
<?php endif; ?>    
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52e9ac57da4d5b885edbde6e81bcb2e3)): ?>
<?php $attributes = $__attributesOriginal52e9ac57da4d5b885edbde6e81bcb2e3; ?>
<?php unset($__attributesOriginal52e9ac57da4d5b885edbde6e81bcb2e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52e9ac57da4d5b885edbde6e81bcb2e3)): ?>
<?php $component = $__componentOriginal52e9ac57da4d5b885edbde6e81bcb2e3; ?>
<?php unset($__componentOriginal52e9ac57da4d5b885edbde6e81bcb2e3); ?>
<?php endif; ?>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $attributes = $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $component = $__componentOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/dainamo/proyectos/soldix-club-godin/resources/views/admin/admins.blade.php ENDPATH**/ ?>