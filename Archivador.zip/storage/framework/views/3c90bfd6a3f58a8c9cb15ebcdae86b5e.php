<div>
    <?php if(session('status')): ?>
        <?php if (isset($component)) { $__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.alert','data' => ['class' => 'mb-4','type' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','type' => 'success']); ?>
            <?php echo e(session('status')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0)): ?>
<?php $attributes = $__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0; ?>
<?php unset($__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0)): ?>
<?php $component = $__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0; ?>
<?php unset($__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0); ?>
<?php endif; ?>
    <?php endif; ?>

    <?php if(session('input_error')): ?>
        <?php if (isset($component)) { $__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.alert','data' => ['class' => 'mb-4','type' => 'error']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','type' => 'error']); ?>
            <?php echo e(session('input_error')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0)): ?>
<?php $attributes = $__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0; ?>
<?php unset($__attributesOriginal17dd0d299daadc2b1ecd1ba218cbefb0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0)): ?>
<?php $component = $__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0; ?>
<?php unset($__componentOriginal17dd0d299daadc2b1ecd1ba218cbefb0); ?>
<?php endif; ?>
    <?php endif; ?>
</div><?php /**PATH /home/dainamo/proyectos/soldix-club-godin/resources/views/components/input-alerts.blade.php ENDPATH**/ ?>