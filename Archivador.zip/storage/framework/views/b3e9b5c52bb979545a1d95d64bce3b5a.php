<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Mis Marcas')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal44c40385a931f546568e2a429adc3059 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal44c40385a931f546568e2a429adc3059 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.centered-content','data' => ['class' => 'py-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::centered-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'py-12']); ?>

        <?php if (isset($component)) { $__componentOriginal92c649acd7dec03de4c2233151f407ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92c649acd7dec03de4c2233151f407ba = $attributes; } ?>
<?php $component = App\View\Components\InputAlerts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-alerts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputAlerts::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92c649acd7dec03de4c2233151f407ba)): ?>
<?php $attributes = $__attributesOriginal92c649acd7dec03de4c2233151f407ba; ?>
<?php unset($__attributesOriginal92c649acd7dec03de4c2233151f407ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92c649acd7dec03de4c2233151f407ba)): ?>
<?php $component = $__componentOriginal92c649acd7dec03de4c2233151f407ba; ?>
<?php unset($__componentOriginal92c649acd7dec03de4c2233151f407ba); ?>
<?php endif; ?>

        <?php if(auth()->user()->is_local_admin): ?>
            <button onclick="showModal('register')" class="flex my-5 ml-2 px-3 py-2 bg-red-500 rounded-md text-white">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user-plus mr-1" width="20" height="25" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                    <circle cx="12" cy="12" r="9" />
                    <line x1="9" y1="12" x2="15" y2="12" />
                    <line x1="12" y1="9" x2="12" y2="15" />
                </svg>
                Agregar
            </button>
        <?php else: ?>
            <p class="mb-2 text-sm font-semibold text-gray-600">Sólo super admin puede agregar nuevos administradores.</p>
        <?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalfec749cfb1ffd5ad42691601346ccfd7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.table','data' => ['hasShadow' => 'true','striped' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hasShadow' => 'true','striped' => 'true']); ?>

             <?php $__env->slot('header', null, []); ?> 
                <th></th>
                <th>Marca</th>
                <th><span class="float-right">Acciones</span> </th>
             <?php $__env->endSlot(); ?>

                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="max-w-min">
                            <div>
                                <?php if($brand->image): ?>
                                    <img src="<?php echo e($brand->image); ?>" width="100px" alt="<?php echo e($brand->name); ?>">
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <div class="ml-3">
                                <div class="text-lg font-medium text-slate-900">
                                    <?php echo e($brand->name); ?>

                                </div>
                            </div>
                        </td>
                        <td>
                            <a href="<?php echo e(route('corporate.brands.view', $brand->id)); ?>" class="flex mr-3 mt-2 px-3 py-2 m-auto bg-green-500 hover:bg-green-400 rounded-md text-white w-11">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-eye-filled" width="20" height="25" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                    <path d="M7 7h-1a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-1" />
                                    <path d="M20.385 6.585a2.1 2.1 0 0 0 -2.97 -2.97l-8.415 8.385v3h3l8.385 -8.415z" />
                                    <path d="M16 5l3 3" />
                                </svg>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7)): ?>
<?php $attributes = $__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7; ?>
<?php unset($__attributesOriginalfec749cfb1ffd5ad42691601346ccfd7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfec749cfb1ffd5ad42691601346ccfd7)): ?>
<?php $component = $__componentOriginalfec749cfb1ffd5ad42691601346ccfd7; ?>
<?php unset($__componentOriginalfec749cfb1ffd5ad42691601346ccfd7); ?>
<?php endif; ?>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal44c40385a931f546568e2a429adc3059)): ?>
<?php $attributes = $__attributesOriginal44c40385a931f546568e2a429adc3059; ?>
<?php unset($__attributesOriginal44c40385a931f546568e2a429adc3059); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal44c40385a931f546568e2a429adc3059)): ?>
<?php $component = $__componentOriginal44c40385a931f546568e2a429adc3059; ?>
<?php unset($__componentOriginal44c40385a931f546568e2a429adc3059); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc5c12b36d74c6daf50fd7453ed806164 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.modal','data' => ['title' => 'Agregar Nueva Marca','name' => 'register','size' => 'large','centerActionButtons' => 'false','okButtonLabel' => '','cancelButtonLabel' => 'Cerrar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Agregar Nueva Marca','name' => 'register','size' => 'large','centerActionButtons' => 'false','okButtonLabel' => '','cancelButtonLabel' => 'Cerrar']); ?>
        <hr class="mb-7 mt-1">
        <form action="<?php echo e(route('corporate.brands.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php if (isset($component)) { $__componentOriginal405a67563ffd994716cfbe38d0ede7bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal405a67563ffd994716cfbe38d0ede7bf = $attributes; } ?>
<?php $component = App\View\Components\InputBlock::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\InputBlock::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'name','placeholder' => 'Ej. Súper Mexicali','value' => ''.e(old('name')).'','required' => true]); ?>
                Nombre de la marca
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal405a67563ffd994716cfbe38d0ede7bf)): ?>
<?php $attributes = $__attributesOriginal405a67563ffd994716cfbe38d0ede7bf; ?>
<?php unset($__attributesOriginal405a67563ffd994716cfbe38d0ede7bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal405a67563ffd994716cfbe38d0ede7bf)): ?>
<?php $component = $__componentOriginal405a67563ffd994716cfbe38d0ede7bf; ?>
<?php unset($__componentOriginal405a67563ffd994716cfbe38d0ede7bf); ?>
<?php endif; ?>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-brand', [])->html();
} elseif ($_instance->childHasBeenRendered('Qv57DDS')) {
    $componentId = $_instance->getRenderedChildComponentId('Qv57DDS');
    $componentTag = $_instance->getRenderedChildComponentTagName('Qv57DDS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Qv57DDS');
} else {
    $response = \Livewire\Livewire::mount('add-brand', []);
    $html = $response->html();
    $_instance->logRenderedChild('Qv57DDS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $attributes = $__attributesOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__attributesOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164)): ?>
<?php $component = $__componentOriginalc5c12b36d74c6daf50fd7453ed806164; ?>
<?php unset($__componentOriginalc5c12b36d74c6daf50fd7453ed806164); ?>
<?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/dainamo/proyectos/soldix-club-godin/resources/views/admin/brands/index.blade.php ENDPATH**/ ?>