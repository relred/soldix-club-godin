<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Agregar cupón nuevo')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php if (isset($component)) { $__componentOriginal44c40385a931f546568e2a429adc3059 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal44c40385a931f546568e2a429adc3059 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'bladewind::components.centered-content','data' => ['class' => 'pb-12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bladewind::centered-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'pb-12']); ?>
        
        <a class="flex w-24 mt-5 px-3 py-2 bg-red-500 rounded-md text-white hover:cursor-pointer" href="<?php echo e(route('corporate.wallets.view', $id)); ?>">← Volver</a>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('add-coupon', ['walletId' => $id,'wallet_id' => $id])->html();
} elseif ($_instance->childHasBeenRendered('jp1xXq5')) {
    $componentId = $_instance->getRenderedChildComponentId('jp1xXq5');
    $componentTag = $_instance->getRenderedChildComponentTagName('jp1xXq5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jp1xXq5');
} else {
    $response = \Livewire\Livewire::mount('add-coupon', ['walletId' => $id,'wallet_id' => $id]);
    $html = $response->html();
    $_instance->logRenderedChild('jp1xXq5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal44c40385a931f546568e2a429adc3059)): ?>
<?php $attributes = $__attributesOriginal44c40385a931f546568e2a429adc3059; ?>
<?php unset($__attributesOriginal44c40385a931f546568e2a429adc3059); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal44c40385a931f546568e2a429adc3059)): ?>
<?php $component = $__componentOriginal44c40385a931f546568e2a429adc3059; ?>
<?php unset($__componentOriginal44c40385a931f546568e2a429adc3059); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/dainamo/proyectos/soldix-club-cuidadores/resources/views/admin/coupons/add.blade.php ENDPATH**/ ?>