<?php return array (
  'add-brand' => 'App\\Http\\Livewire\\AddBrand',
  'add-coupon' => 'App\\Http\\Livewire\\AddCoupon',
  'revenue-projection' => 'App\\Http\\Livewire\\RevenueProjection',
  'select-gadget' => 'App\\Http\\Livewire\\SelectGadget',
);