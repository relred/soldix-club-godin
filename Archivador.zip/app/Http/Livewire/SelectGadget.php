<?php

namespace App\Http\Livewire;

use Livewire\Component;

class SelectGadget extends Component
{
    public function render()
    {
        return view('livewire.select-gadget');
    }
}
